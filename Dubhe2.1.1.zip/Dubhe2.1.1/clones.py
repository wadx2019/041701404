import sys,os
import git
import shutil
def isSnum(name):
	if len(name)==9 and name.isdigit():
		return True
	else:
		return False
git.Repo.clone_from(sys.argv[1],sys.argv[2])
os.chdir(sys.argv[2])
for item in os.listdir(sys.argv[2]):
	if os.path.isdir(item):
		if isSnum(item):
			shutil.move(sys.argv[2]+"\\"+item,sys.argv[3])
			exit()
	else:
		if item.endswith(".py") and isSnum(os.path.splitext(item)[0]):
			shutil.copy(sys.argv[2]+"\\"+item,sys.argv[3])
			exit()
raise Exception("仅接受以学号命名的文件夹或py文件！\n")