# coding=utf-8
import os,sys,json
def _find_file():
	
	path_list=[]
	for item in os.listdir(os.curdir+"\\pycode"):
		if item.endswith(".py"):
			path_list.append("pycode\\"+item)
	return path_list

print(sys.argv[1])
os.chdir(sys.argv[1])
_lp=_find_file()
for _f in _lp:
	_f_name,_=os.path.splitext(_f)
	_,_f_dir=os.path.split(_f_name)
	_input_file=sys.argv[2]
	_exec_file=_f
	_output_file=sys.argv[1]+"\\json_file"+"\\"+_f_dir+".json"
	_json_collect=[]
	_stdintmp=sys.stdin
	_stdouttmp=sys.stdout
	with open(_input_file,'r',encoding="utf-8") as __input_file:
		for _lines in list(filter(None,__input_file.read().split('\n'))):
			print(_lines)
			_temp=open("_tmp.txt",'w',encoding="utf-8")
			_temp.write(_lines)
			_temp.close()
			sys.stdin=open("_tmp.txt",'r',encoding="utf-8")
			with open(_output_file,'w',encoding="utf-8") as sys.stdout:
				_pyexec=open(_exec_file,'r',encoding="utf-8")
				exec(_pyexec.read())
				_pyexec.close()
			sys.stdin.close()
			_json_file=open(_output_file,'r',encoding="utf-8")
			_json_collect.append(json.load(_json_file,encoding="utf-8"))
			_json_file.close()
			sys.stdin=_stdintmp
			sys.stdout=_stdouttmp
			os.remove("_tmp.txt")
	_json_final=open(_output_file,'w',encoding="utf-8")
	json.dump(_json_collect,_json_final,ensure_ascii=False)
	_json_final.close()



