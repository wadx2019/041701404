import os
try:
	import git
except:
	os.system("pip install gitpython")
try:
	import pygame
except:
	os.system("pip install pygame")