# coding=utf-8
import os,sys,json
print(sys.argv[1])
root,_=os.path.split(sys.argv[1])
output_dir=root+"\\json_file\\"
pydir=root+"\\pycode"
def isSnum(name,Snum):
	_,name=os.path.split(name)
	name,_=os.path.splitext(name)
	if name==Snum:
		return True
	else:
		return False
def addtxt(execf,Snum,input_file):
	global output_dir
	headlist=["import sys,os\n","os.chdir(r\""+pydir+"\")\n","sys.stdin=open(r'"+input_file+"','r',encoding='utf-8')\n","sys.stdout=open(r'"+output_dir+Snum+".json','a+',encoding='utf-8')\n"]
	endlist=["\nsys.stdout.close()\n","sys.stdin.close()\n"]
	if execf.split()[0].startswith("#"):
		return "# -*- coding: utf-8 -*-\n"+''.join(headlist)+execf+''.join(endlist)
	else:
		return ''.join(headlist)+execf+''.join(endlist)
def adjust(Snum,text):
	os.system("echo "+text+" >> \""+output_dir+Snum+".json\"")

def main(input_file,exec_file,Snum):
	execf=open(exec_file,'r',encoding="utf-8")
	exectxt=execf.read()
	execf.close()
	execadd=addtxt(exectxt,Snum,root+"\\tmp.txt")
	execf=open(exec_file,'w',encoding="utf-8")
	execf.write(execadd)
	execf.close()
	adjust(Snum,"[")
	fin=open(input_file,'r',encoding="utf-8")
	judge=False
	cnt=0
	for line in fin.readlines():
		if judge:
			adjust(Snum,",")
		judge=True
		f=open(root+"\\tmp.txt",'w',encoding="utf-8")
		f.write(line)
		f.close()
		cnt+=1
		print(cnt,"item(s) have been finished")
		if os.system("python \""+exec_file+"\""):
			adjust(Snum,"{}")
	adjust(Snum,"]")
	os.remove(root+"\\tmp.txt")
	fin.close()

def find_file(filepath,Snum):
	for item in os.listdir(filepath):
		if item.endswith(".py") and isSnum(item,Snum):
			return item
	raise Exception("没有找到以学号命名的py主文件！\n")

#1:collect dir , 2:input file

for st_dir in os.listdir(sys.argv[1]):
	if not st_dir.endswith(".py"):
		cur_dir=sys.argv[1]+"\\"+st_dir
		exec_address=find_file(cur_dir,st_dir)
		print(cur_dir+"\\"+exec_address)
		main(sys.argv[2],cur_dir+"\\"+exec_address,st_dir)
	else:
		stdir,_=os.path.splitext(st_dir)
		main(sys.argv[2],sys.argv[1]+"\\"+st_dir,stdir)


