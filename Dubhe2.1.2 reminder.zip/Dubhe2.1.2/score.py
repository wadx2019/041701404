import json,sys,os
emark=False
def open_json(file_path):
	with open(file_path,encoding='utf-8') as f:
		js_object=json.load(f,encoding='utf-8')
	return js_object
def score(out_file,std_file):
	global emark
	s=1.0
	w=0.0
	for item in std_file.keys():
		if item=="level":
			if std_file[item]==1:
				w=0.08
			elif std_file[item]==2:
				w=0.2
			else:
				w=0.5
			continue
		if out_file.__contains__(item) and out_file[item]==std_file[item]:
			continue
		else:
			s-=0.5
			emark=True
	if s<0:
		return 0
	else:
		return s*w

sums=0.0
enum=0
error_list=[]
fout=open_json(sys.argv[1])
fstd=open_json(sys.argv[2])
if len(fout)!= len(fstd):
	print(len(fout),len(fstd))
	raise Exception("An unknown error happened!\n")
for i in range(len(fstd)):
	sums+=score(fout[i],fstd[i])
	if emark:
		enum+=1
		error_list.append(i)
		emark=False
_,fout_dir=os.path.split(sys.argv[1])
fout_name,_=os.path.splitext(fout_dir)
fstd_dir,_=os.path.split(sys.argv[2])
with open(fstd_dir+"\\grade.csv",'a+',encoding="utf-8") as f:
	if fout_name.endswith(".py"):
		fout_name,_=os.path.splitext(fout_name)
	f.write(fout_name+"\t,"+str(sums)+'\n')
print()
print("You have "+str(enum)+" error(s) "+"in case "+str(error_list)+'\n')
print("Your final score is",str(int(sums))+"/125")