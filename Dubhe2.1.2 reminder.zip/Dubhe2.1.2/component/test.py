# coding=utf-8

def run(path):
	
	_pyexec=open(path,'r',encoding="utf-8")
	exec(_pyexec.read())
	_pyexec.close()

run(r"C:\Users\HP\Desktop\ss.py")
